#include <iostream>
#include <fstream>
using namespace std;
struct Book {
    string id;
    string name;
    string author;
};
struct Student {
    string id;
    string password;
    string name;
};
//Declaration of All Functions Used
void adminMenu();
void studentMenu();
bool adminLogin();
bool studentLogin();
void createStudentAccount();
void editAccount();
void showAll();
void addBook();
void editBook();
void searchBook();
void deleteBook();
void borrowBook();
void returnBook();
//Main Program
int main() {
    char choice;
    do {
    cout << "\n=======================================" << endl;
    cout << "         LIBRARY MANAGEMENT SYSTEM       " << endl;
    cout << "=========================================" << endl;
        cout << "1- Admin Login" << endl;
        cout << "2- Student Login" << endl;
        cout << "3- Create Student Account" << endl;
        cout << "4- Edit Account" << endl;
        cout << "5- Exit" << endl;
        cout << "----------------------------------" << endl;
        cout << "Enter Your Choice :: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
        case '1':
            if (adminLogin()) adminMenu();
            break;
        case '2':
            if (studentLogin()) studentMenu();
            break;
        case '3':
            createStudentAccount();
            break;
        case '4':
            editAccount();
            break;
        case '5':
            cout << "Exiting Program..." << endl;
            break;
        default:
            cout << "Invalid Choice!" << endl;
        }
    } while (choice != '5');
    return 0;
}
//Function Defination for Login of Admin
bool adminLogin() {
    string adminID = "admin";
    string adminPassword = "password";
    string inputID, inputPassword;
    cout << "Enter Admin ID: ";
    cin >> inputID;
    cout << "Enter Admin Password: ";
    cin >> inputPassword;
    if (inputID == adminID && inputPassword == adminPassword) {
        cout << "Admin Login Successful!" << endl<<endl;
        return true;
    } else {
        cout << "Invalid Admin ID or Password!" << endl<<endl;
        return false;
    }
}
//Function Defination for Menu of Admin
void adminMenu() {
    char choice;
    do {
        cout << "Admin Menu" << endl;
        cout << "1- Show All Books" << endl;
        cout << "2- Add Book" << endl;
        cout << "3- Edit Book" << endl;
        cout << "4- Search Book" << endl;
        cout << "5- Delete Book" << endl;
        cout << "6- Exit" << endl;
        cout << "----------------------------------" << endl;
        cout << "Enter Your Choice :: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
        case '1':
            showAll();
            break;
        case '2':
            addBook();
            break;
        case '3':
            editBook();
            break;
        case '4':
            searchBook();
            break;
        case '5':
            deleteBook();
            break;
        case '6':
            cout << "Exiting Admin Menu..." << endl;
            break;
        default:
            cout << "Invalid Choice!" << endl;
        }
    } while (choice != '6');
}
//Function Defination of Student Login
bool studentLogin() {
    string inputID, inputPassword;
    Student student;
    fstream file("studentdata.txt", ios::in);
    if (!file) {
        cout << "No student accounts found. Please create an account first!" << endl;
        return false;
    }
    cout << "Enter Student ID: ";
    cin >> inputID;
    cout << "Enter Password: ";
    cin >> inputPassword;
    while (file >> student.id >> student.password >> student.name) {
        if (student.id == inputID && student.password == inputPassword) {
            cout << "Student Login Successful!" << endl<<endl;
            file.close();
            return true;
        }
    }
    cout << "Invalid Student Credentials!" << endl<<endl;
    file.close();
    return false;
}
//Function Defination for Display of Student Menu
void studentMenu() {
    char choice;
    do {
        cout << "Student Menu" << endl;
        cout << "1- Show All Books" << endl;
        cout << "2- Borrow Book" << endl;
        cout << "3- Return Book" << endl;
        cout << "4- Search Book" << endl;
        cout << "5- Exit" << endl;
        cout << "----------------------------------" << endl;
        cout << "Enter Your Choice :: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
        case '1':
            showAll();
            break;
        case '2':
            borrowBook();
            break;
        case '3':
            returnBook();
            break;
        case '4':
            searchBook();
            break;
        case '5':
            cout << "Exiting Student Menu..." << endl;
            break;
        default:
            cout << "Invalid Choice!" << endl;
        }
    } while (choice != '5');
}
//Function Defination for Creation of Student Account
void createStudentAccount() {
    Student student;
    fstream file("studentdata.txt", ios::out | ios::app);
    cout << "Enter Student ID: ";
    cin >> student.id;
    cout << "Enter Password: ";
    cin >> student.password;
    cin.ignore();
    cout << "Enter Student Name: ";
    getline(cin, student.name);
    file << student.id << " " << student.password << " " << student.name << endl;
    file.close();
    cout << "Student Account Created Successfully!" << endl<<endl;
}
//Function Defination for Student Account for Editing
void editAccount() {
    string studentID;
    Student student;
    bool found = false;
    fstream file("studentdata.txt", ios::in);
    fstream tempFile("tempdata.txt", ios::out);
    if (!file) {
        cout << "No student accounts found!" << endl;
        return;
    }
    cout << "Enter Student ID to Edit: ";
    cin >> studentID;
    cin.ignore();
    while (file >> student.id >> student.password >> student.name) {
        if (student.id == studentID) {
            found = true;
            cout << "Enter New Password: ";
            cin >> student.password;
            cin.ignore();
            cout << "Enter New Name: ";
            getline(cin, student.name);
            cout << "Student Account Updated Successfully!" << endl;
        }
        tempFile << student.id << " " << student.password << " " << student.name << endl;
    }
    if (!found) {
        cout << "Student ID not found!" << endl;
    }
    file.close();
    tempFile.close();
    remove("studentdata.txt");
    rename("tempdata.txt", "studentdata.txt");
}
//Function Defination of Adding New Books
void addBook() {
    Book book;
    fstream file("bookData.txt", ios::out | ios::app);
    if (!file) {
        cout << "Error opening file for writing!" << endl;
        return;
    }
    cout << "\nEnter Book ID: ";
    getline(cin, book.id);
    cout << "Enter Book Name: ";
    getline(cin, book.name);
    cout << "Enter Author Name: ";
    getline(cin, book.author);

    file << book.id << "\n\n" << book.name << "\n\n" << book.author << "\n";
    file.close();
    cout << "Book Added Successfully!" << endl << endl;
}
//Function Defination for Displaying All Books
void showAll() {
    Book book;
    fstream file;
    file.open("bookData.txt", ios::in);
    if (!file) {
        cout << "No books found. Please add books first!" << endl;
        return;
    }
    cout << "\n\n\tBook ID\t\tBook Name\t\tAuthor's Name" << endl;
    cout << "--------------------------------------------------------------------" << endl;
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        cout << "\t" << book.id << "\t\t" << book.name << "\t\t" << book.author << endl;
    }
    file.close();
}
//Function Defination for Borrowing of Books
void borrowBook() {
    string search;
    showAll();
    cout << "Enter Book ID to Borrow :: ";
    getline(cin, search);
    fstream file, tempFile, borrowFile;
    Book book;
    bool found = false;
    file.open("bookData.txt", ios::in);
    tempFile.open("tempData.txt", ios::out);
    borrowFile.open("borrowedBooks.txt", ios::out | ios::app);
    if (!file || !tempFile || !borrowFile) {
        cout << "Error opening file!" << endl;
        return;
    }
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        if (search == book.id) {
            borrowFile << book.id << "*" << book.name << "*" << book.author << endl;
            cout << "Book ID '" << book.id << "' borrowed successfully!" << endl;
            found = true;
        } else {
            tempFile << book.id << "*" << book.name << "*" << book.author << endl;
        }
    }
    if (!found) {
        cout << "Book ID '" << search << "' not found!" << endl;
    }
    file.close();
    tempFile.close();
    borrowFile.close();
    remove("bookData.txt");
    rename("tempData.txt", "bookData.txt");
}
//Function Defination for Return of Books
void returnBook() {
    string search;
    Book book;
    fstream file, tempFile, mainFile;
    file.open("borrowedBooks.txt", ios::in);
    if (!file) {
        cout << "No borrowed books found!" << endl;
        return;
    }
    cout << "\nBorrowed Books:\n";
    cout << "\n\n\tBook ID\t\tBook Name\t\tAuthor's Name" << endl;
    cout << "--------------------------------------------------------------------" << endl;
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        cout << "\t" << book.id << "\t\t" << book.name << "\t\t" << book.author << endl;
    }
    file.close();
    cout << "Enter Book ID to Return :: ";
    getline(cin, search);
    file.open("borrowedBooks.txt", ios::in);
    tempFile.open("tempData.txt", ios::out);
    mainFile.open("bookData.txt", ios::out | ios::app);
    bool found = false;
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        if (search == book.id) {
            mainFile << book.id << "*" << book.name << "*" << book.author << endl;
            cout << "Book ID '" << book.id << "' returned successfully!" << endl;
            found = true;
        } else {
            tempFile << book.id << "*" << book.name << "*" << book.author << endl;
        }
    }
    if (!found) {
        cout << "Book ID '" << search << "' not found in borrowed books!" << endl;
    }
    file.close();
    tempFile.close();
    mainFile.close();
    remove("borrowedBooks.txt");
    rename("tempData.txt", "borrowedBooks.txt");
}
//Function Defination for Deleting Existing Books in System
void deleteBook() {
    string search;
    char locationChoice;
    Book book;
    cout << "\nWhere do you want to delete the book from?\n";
    cout << "1- Main Book List\n";
    cout << "2- Borrowed Books List\n";
    cout << "Enter your choice: ";
    cin >> locationChoice;
    cin.ignore();
    string filename = (locationChoice == '1') ? "bookData.txt" : "borrowedBooks.txt";
    fstream file(filename.c_str(), ios::in);
    if (!file) {
        cout << "No books found in the selected list!" << endl;
        return;
    }
    fstream tempFile("tempData.txt", ios::out);
    bool found = false;
    cout << "\n\n\tBook ID\t\tBook Name\t\tAuthor's Name" << endl;
    cout << "--------------------------------------------------------------------" << endl;
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        cout << "\t" << book.id << "\t\t" << book.name << "\t\t" << book.author << endl;
    }
    file.close();
    cout << "Enter Book ID to Delete: ";
    getline(cin, search);
    file.open(filename.c_str(), ios::in);
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        if (search == book.id) {
            cout << "Book ID '" << book.id << "' deleted successfully!" << endl;
            found = true;
        } else {
            tempFile << book.id << "*" << book.name << "*" << book.author << endl;
        }
    }
    if (!found) {
        cout << "Book ID '" << search << "' not found in the selected list!" << endl;
    }
    file.close();
    tempFile.close();
    remove(filename.c_str());
    rename("tempData.txt", filename.c_str());
}
//Function Defination for Editing of Existing books
void editBook() {
    string search;
    Book book;
    bool found = false;
    cout << "\nEnter Book ID to Edit: ";
    getline(cin, search);
    fstream file("bookData.txt", ios::in);
    fstream tempFile("tempData.txt", ios::out);
    if (!file || !tempFile) {
        cout << "Error opening file!" << endl;
        return;
    }
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        if (search == book.id) {
            found = true;
            cout << "\nEnter New Name of Book: ";
            getline(cin, book.name);
            cout << "Enter New Author Name of Book: ";
            getline(cin, book.author);
            cout << "Book details updated successfully!" << endl;
        }
        tempFile << book.id << "*" << book.name << "*" << book.author << endl;
    }
    if (!found) {
        cout << "Book ID '" << search << "' not found!" << endl;
    }
    file.close();
    tempFile.close();
    remove("bookData.txt");
    rename("tempData.txt", "bookData.txt");
}
//Function Defination for Searching of Books
void searchBook() {
    string search;
    char choice;
    bool found = false;
    cout << "\nSearch by:\n1- Book ID\n2- Book Name\nEnter choice: ";
    cin >> choice;
    cin.ignore();
    cout << "Enter Search Query: ";
    getline(cin, search);
    Book book;
    fstream file("bookData.txt", ios::in);
    if (!file) {
        cout << "No books found!" << endl;
        return;
    }
    cout << "\n\n\tBook ID\t\tBook Name\t\tAuthor's Name" << endl;
    cout << "--------------------------------------------------------------------" << endl;
    while (getline(file, book.id, '*') && getline(file, book.name, '*') && getline(file, book.author)) {
        if ((choice == '1' && book.id == search) || (choice == '2' && book.name.find(search) != string::npos)) {
            cout << "\t" << book.id << "\t\t" << book.name << "\t\t" << book.author << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "No results found for the given query!" << endl;
    }
    file.close();
}
